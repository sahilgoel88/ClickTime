﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SpecFlowProject1.Infra
{
    public enum Browser
    {
        Chrome,
        Firefox
    }
}

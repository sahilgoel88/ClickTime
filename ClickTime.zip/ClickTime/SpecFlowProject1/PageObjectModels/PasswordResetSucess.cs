﻿using SpecFlowProject1.Infra;
using SpecFlowProject1.PageObjectModels.Base;
using System;
using System.Collections.Generic;
using System.Text;

namespace SpecFlowProject1.PageObjectModels
{
    class PasswordResetSucess : PageObjectModel
    {
        public PasswordResetSucess(IBrowserHelper helper, ConfigurationHelper configuration) : base(helper, configuration)
        {
        }

       
        public string GetMessage()
        {
            return BrowserHelper.GetElementTextByXpath("//h2[contains(text(),'Reset Password Request Completed!')]");
        }

     

    }
}

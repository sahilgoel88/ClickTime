﻿using SpecFlowProject1.Infra;
using SpecFlowProject1.PageObjectModels.Base;
using System;
using System.Collections.Generic;
using System.Text;

namespace SpecFlowProject1.PageObjectModels
{
    class PasswordResetPage : PageObjectModel
    {
        public PasswordResetPage(IBrowserHelper helper, ConfigurationHelper configuration) : base(helper, configuration)
        {
        }

        public void GoToPage()
        {
            BrowserHelper.NavigateTo(Configuration.PasswordResetUrl);
        }
        
        public void TypeCredentials(string email)
        {
            BrowserHelper.TypeTextByXpath("//input[@id='username']", email);


        }
        
        public void ClickPasswordResetButton()
        {
            BrowserHelper.ClickByXath("//input[@id='passwordReset']");
        }
        
        public string GetMessage()
        {
                return BrowserHelper.GetElementTextByXpath("//span[contains(text(),'Not a valid email address.')]");
        }

        public string GetMessageTwo()
        {
                return BrowserHelper.GetElementTextByXpath("//span[contains(text(),'Required. Cannot be left blank.')]");
        }

        public void CloseBrowser()
        {
            BrowserHelper.CloseBroswer();
        }
        
        public string GetUrl()
        {
            return BrowserHelper.GetCurrentUrl();
        }

    }
}

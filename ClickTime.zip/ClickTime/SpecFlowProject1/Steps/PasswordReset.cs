﻿using FluentAssertions;
using SpecFlowProject1.Fixtures;
using SpecFlowProject1.PageObjectModels;
using System;
using TechTalk.SpecFlow;
using Xunit;

namespace SpecFlowProject1.Steps
{
    [Binding]
    [CollectionDefinition(nameof(WebTestFixtureCollection))]
    public class PasswordReset
    {
        private readonly WebTestFixture _webTestFixture;
        private readonly PasswordResetPage _PasswordResetPage;
        private readonly PasswordResetSucess _PasswordResetSucess;
        public string emailID;
        public PasswordReset(WebTestFixture webTestFixture)
        {
            _webTestFixture = webTestFixture;
            _PasswordResetPage = new PasswordResetPage(_webTestFixture.BrowserHelper, _webTestFixture.Configuration);
            _PasswordResetSucess = new PasswordResetSucess(_webTestFixture.BrowserHelper, _webTestFixture.Configuration);
        }

        [Given(@"The user navigates to the Password Reset Page")]
        public void GivenTheUserNavigatesToThePasswordResetPage()
        {
            _PasswordResetPage.GoToPage();
        }

        [Given(@"The user Provides (.*)")]
        public void GivenTheUserProvides(string emailAddress)
        {
            emailID = emailAddress;
            _PasswordResetPage.TypeCredentials(emailID);
        }

        [When(@"They press the Send Password Reset Link Button")]
        public void WhenTheyPressTheSendPasswordResetLinkButton()
        {
            _PasswordResetPage.ClickPasswordResetButton();
        }

        [Then(@"The Error message on page should match the (.*)")]
        public void ThenTheErrorMessageOnPageShouldMatchThe(string errorMessage)
        {

            string currentURL = _PasswordResetPage.GetUrl();

            Assert.NotEqual("https://login.clicktime.com/qa/passReset?result=success&status=success", _PasswordResetPage.GetUrl());

            if (emailID != "")
            {
                Assert.Equal(errorMessage, _PasswordResetPage.GetMessage());
            }
            else
            {
                Assert.Equal(errorMessage, _PasswordResetPage.GetMessageTwo());
            }
        }


        [Then(@"The user Should redirected to Password Reset Completed Page")]
        public void ThenTheUserShouldRedirectedToPasswordResetCompletedPage()
        {
            Assert.Equal("https://login.clicktime.com/qa/passReset?result=success&status=success", _PasswordResetPage.GetUrl());
            string textToVerify = _PasswordResetSucess.GetMessage();
            Assert.Equal("Reset Password Request Completed!", textToVerify);
        }


        [AfterScenario]
        public void afterScenario()
        {
            _PasswordResetPage.CloseBrowser();
        }

       
    }

}

